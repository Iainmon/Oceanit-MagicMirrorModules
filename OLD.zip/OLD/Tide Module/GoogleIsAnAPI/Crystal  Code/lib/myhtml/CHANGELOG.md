## 1.1.0 (2018-09-23)
* Add Myhtml::Parser#to_html, fixed #11
* Update Modest to last revision
* Cleanups, refactors

## 1.0.0 (2018-08-04)
* Merge myhtml v0.30 with modest v0.17
