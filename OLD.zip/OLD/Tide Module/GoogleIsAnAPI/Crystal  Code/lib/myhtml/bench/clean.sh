rm *.dwarf
rm bin_*
rm google.html
rm -rf lib
