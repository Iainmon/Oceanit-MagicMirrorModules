To compile all: `sh build.sh`

To run all: `sh run.sh`