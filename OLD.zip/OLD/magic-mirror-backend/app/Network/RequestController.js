class RequestController {
}

module.exports ={
    RequestController : RequestController
};