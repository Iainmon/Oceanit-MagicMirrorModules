const Func = require('./Func/Func.js').Func;
const Query = require('./Network/QueryController.js').QueryController;
const Request = require('./Network/RequestController.js').RequestController;

module.exports = {
    Func : Func,
    Query : Query,
    Request : Request,
};